import hashlib
from datetime import date

from src.request_repository import RequestRepository


class RequestService:
    def __init__(self):
        self.repository = RequestRepository()

    def get_all_requests(self, filters=None):
        return self.repository.get_all(filters)

    def get_request(self, request_id):
        return self.repository.get_by_id(request_id)

    def create_request(self, data, requester_id):
        self._validate_request(data)
        return self.repository.create(data, requester_id)

    def update_request(self, request_id, data):
        self._validate_request(data)
        return self.repository.update(request_id, data)

    def change_status(self, request_id, status, user_id):
        if status not in self.repository.get_statuses():
            raise ValueError("Выбран неизвестный статус.")
        return self.repository.update_status(request_id, status, user_id)

    def get_categories(self):
        return self.repository.get_categories()

    def get_statuses(self):
        return self.repository.get_statuses()

    def get_history(self, request_id):
        return self.repository.get_history(request_id)

    def login(self, email, password):
        if not email or not password:
            raise ValueError("Введите электронную почту и пароль.")
        user = self.repository.get_password_record(email.strip().lower())
        if not user:
            return None

        try:
            algorithm, iterations, salt, saved_hash = user["password_hash"].split("$")
            if algorithm != "pbkdf2_sha256":
                return None
            password_hash = hashlib.pbkdf2_hmac(
                "sha256",
                password.encode("utf-8"),
                bytes.fromhex(salt),
                int(iterations)
            ).hex()
        except (ValueError, TypeError):
            return None

        if password_hash != saved_hash:
            return None

        user.pop("password_hash")
        return user

    def _validate_request(self, data):
        if not isinstance(data, dict):
            raise ValueError("Данные заявки должны быть объектом.")

        required = ("school", "category", "count", "date")
        for field in required:
            if not str(data.get(field, "")).strip():
                raise ValueError("Заполните все обязательные поля.")

        try:
            count = int(data["count"])
            if float(data["count"]) != count:
                raise ValueError
        except (TypeError, ValueError):
            raise ValueError("Количество учащихся должно быть целым числом.")

        if count <= 0:
            raise ValueError("Количество учащихся должно быть больше нуля.")

        try:
            date.fromisoformat(str(data["date"]))
        except ValueError:
            raise ValueError("Укажите корректную дату в формате ГГГГ-ММ-ДД.")

        if data["category"] not in self.repository.get_categories():
            raise ValueError("Выбрана неизвестная категория.")

        if len(str(data["school"]).strip()) > 200:
            raise ValueError("Название учреждения слишком длинное.")

        if len(str(data.get("description", ""))) > 2000:
            raise ValueError("Описание не должно превышать 2000 символов.")
