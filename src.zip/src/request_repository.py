from database.db import get_connection


class RequestRepository:
    def get_all(self, filters=None):
        filters = filters or {}
        query = """
            SELECT
                r.request_id,
                r.request_number,
                r.requester_id,
                u.full_name AS requester,
                s.status_name,
                c.category_name,
                r.institution_name,
                r.student_count,
                r.meal_date,
                r.description,
                r.created_at,
                r.executor_id
            FROM Requests r
            JOIN Users u ON r.requester_id = u.user_id
            JOIN Statuses s ON r.status_id = s.status_id
            JOIN Categories c ON r.category_id = c.category_id
            WHERE 1 = 1
        """
        params = []

        if filters.get("status"):
            query += " AND s.status_name = ?"
            params.append(filters["status"])
        if filters.get("category"):
            query += " AND c.category_name = ?"
            params.append(filters["category"])
        if filters.get("date_from"):
            query += " AND r.meal_date >= ?"
            params.append(filters["date_from"])
        if filters.get("date_to"):
            query += " AND r.meal_date <= ?"
            params.append(filters["date_to"])
        if filters.get("search"):
            query += " AND (r.request_number LIKE ? OR r.institution_name LIKE ?)"
            value = "%" + filters["search"] + "%"
            params.extend([value, value])

        query += " ORDER BY r.created_at DESC, r.request_id DESC"

        connection = get_connection()
        try:
            return [dict(row) for row in connection.execute(query, params).fetchall()]
        finally:
            connection.close()

    def get_by_id(self, request_id):
        connection = get_connection()
        try:
            row = connection.execute("""
                SELECT
                    r.request_id, r.request_number, r.requester_id, r.executor_id,
                    u.full_name AS requester, s.status_name, c.category_name,
                    r.institution_name, r.student_count, r.meal_date,
                    r.description, r.created_at
                FROM Requests r
                JOIN Users u ON r.requester_id = u.user_id
                JOIN Statuses s ON r.status_id = s.status_id
                JOIN Categories c ON r.category_id = c.category_id
                WHERE r.request_id = ?
            """, (request_id,)).fetchone()
            return dict(row) if row else None
        finally:
            connection.close()

    def create(self, data, requester_id):
        connection = get_connection()
        try:
            category = connection.execute(
                "SELECT category_id FROM Categories WHERE category_name = ?",
                (data["category"],)
            ).fetchone()
            if not category:
                raise ValueError("Выбрана неизвестная категория.")

            number_row = connection.execute(
                "SELECT COALESCE(MAX(request_id), 0) + 1 FROM Requests"
            ).fetchone()
            next_number = number_row[0]
            request_number = f"REQ-{next_number:03d}"

            cursor = connection.execute("""
                INSERT INTO Requests (
                    request_number, requester_id, status_id, category_id,
                    institution_name, student_count, meal_date, description
                )
                VALUES (?, ?, 1, ?, ?, ?, ?, ?)
            """, (
                request_number, requester_id, category["category_id"],
                data["school"], data["count"], data["date"], data["description"]
            ))
            request_id = cursor.lastrowid
            connection.execute(
                "INSERT INTO StatusHistory (request_id, status_id, user_id) VALUES (?, 1, ?)",
                (request_id, requester_id)
            )
            connection.commit()
            return self.get_by_id(request_id)
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def update(self, request_id, data):
        connection = get_connection()
        try:
            category = connection.execute(
                "SELECT category_id FROM Categories WHERE category_name = ?",
                (data["category"],)
            ).fetchone()
            if not category:
                raise ValueError("Выбрана неизвестная категория.")

            cursor = connection.execute("""
                UPDATE Requests
                SET institution_name = ?, category_id = ?, student_count = ?,
                    meal_date = ?, description = ?
                WHERE request_id = ?
            """, (
                data["school"], category["category_id"], data["count"],
                data["date"], data["description"], request_id
            ))
            if cursor.rowcount == 0:
                return None
            connection.commit()
            return self.get_by_id(request_id)
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def update_status(self, request_id, status_name, user_id):
        connection = get_connection()
        try:
            status = connection.execute(
                "SELECT status_id FROM Statuses WHERE status_name = ?",
                (status_name,)
            ).fetchone()
            if not status:
                raise ValueError("Выбран неизвестный статус.")

            cursor = connection.execute(
                "UPDATE Requests SET status_id = ? WHERE request_id = ?",
                (status["status_id"], request_id)
            )
            if cursor.rowcount == 0:
                return None

            connection.execute(
                "INSERT INTO StatusHistory (request_id, status_id, user_id) VALUES (?, ?, ?)",
                (request_id, status["status_id"], user_id)
            )
            connection.commit()
            return self.get_by_id(request_id)
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def get_categories(self):
        connection = get_connection()
        try:
            return [row["category_name"] for row in connection.execute(
                "SELECT category_name FROM Categories ORDER BY category_id"
            ).fetchall()]
        finally:
            connection.close()

    def get_statuses(self):
        connection = get_connection()
        try:
            return [row["status_name"] for row in connection.execute(
                "SELECT status_name FROM Statuses ORDER BY status_id"
            ).fetchall()]
        finally:
            connection.close()

    def get_history(self, request_id):
        connection = get_connection()
        try:
            rows = connection.execute("""
                SELECT s.status_name, h.changed_at, u.full_name
                FROM StatusHistory h
                JOIN Statuses s ON h.status_id = s.status_id
                LEFT JOIN Users u ON h.user_id = u.user_id
                WHERE h.request_id = ?
                ORDER BY h.history_id
            """, (request_id,)).fetchall()
            return [dict(row) for row in rows]
        finally:
            connection.close()

    def get_password_record(self, email):
        connection = get_connection()
        try:
            row = connection.execute(
                "SELECT user_id, full_name, email, role, password_hash FROM Users WHERE email = ?",
                (email,)
            ).fetchone()
            return dict(row) if row else None
        finally:
            connection.close()
